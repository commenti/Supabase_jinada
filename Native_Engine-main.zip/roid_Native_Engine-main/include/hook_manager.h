#pragma once

namespace observer::hooks {
    void init();
    void teardown();
} // namespace observer::hooks