#include <jni.h>
#include <atomic>
#include "config.h"
#include "hook_manager.h"

namespace observer::dispatcher {
    void start();
    void stop();
} // namespace observer::dispatcher

static std::atomic<bool> s_lib_loaded{false};

extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    if (s_lib_loaded.exchange(true)) return JNI_VERSION_1_6;

    // Initialize lock-free dispatcher thread
    observer::dispatcher::start();

    // Initialize hook subsystems (conditionally active based on DISABLE_BYTEHOOK)
    observer::hooks::init();

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL JNI_OnUnload(JavaVM*, void*) {
    if (!s_lib_loaded.exchange(false)) return;

    // Tear down hooks first to stop data ingestion
    observer::hooks::teardown();

    // Stop dispatcher thread and flush/join
    observer::dispatcher::stop();
}

} // extern "C"