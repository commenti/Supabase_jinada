#include "config.h"
#include "ring_buffer.h"
#include "hook_manager.h"
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <cstring>

#ifndef DISABLE_BYTEHOOK
#include <bytehook.h>

namespace observer::hooks {
namespace detail {
    static ssize_t (*orig_send)(int sockfd, const void *buf, size_t len, int flags);
    static ssize_t (*orig_recv)(int sockfd, void *buf, size_t len, int flags);

    static ssize_t hooked_send(int sockfd, const void *buf, size_t len, int flags) {
        if (buf != nullptr && len > 0) {
            const uint32_t capture_len = static_cast<uint32_t>(len < config::RB_PAYLOAD_MAX ? len : config::RB_PAYLOAD_MAX);
            core::g_ring_buffer.push(buf, capture_len);
        }
        return orig_send(sockfd, buf, len, flags);
    }

    static ssize_t hooked_recv(int sockfd, void *buf, size_t len, int flags) {
        const ssize_t ret = orig_recv(sockfd, buf, len, flags);
        if (ret > 0 && buf != nullptr) {
            const uint32_t capture_len = static_cast<uint32_t>(ret < config::RB_PAYLOAD_MAX ? ret : config::RB_PAYLOAD_MAX);
            core::g_ring_buffer.push(buf, capture_len);
        }
        return ret;
    }
} // namespace detail
} // namespace observer::hooks
#endif

namespace observer::hooks {

void init() {
#ifndef DISABLE_BYTEHOOK
    bytehook_init_cfg_t cfg{};
    cfg.mode          = BYTEHOOK_MODE_AUTOMATIC;
    cfg.callback      = nullptr;
    cfg.callback_data = nullptr;

    if (bytehook_init(&cfg) == BYTEHOOK_SUCCESS) {
        bytehook_hook_single(
            "libc.so",
            nullptr,
            "send",
            reinterpret_cast<void*>(detail::hooked_send),
            reinterpret_cast<void**>(&detail::orig_send),
            nullptr,
            nullptr
        );

        bytehook_hook_single(
            "libc.so",
            nullptr,
            "recv",
            reinterpret_cast<void*>(detail::hooked_recv),
            reinterpret_cast<void**>(&detail::orig_recv),
            nullptr,
            nullptr
        );
        OBS_LOG(ANDROID_LOG_INFO, "Network hooks registered via ByteHook.");
    } else {
        OBS_LOG(ANDROID_LOG_ERROR, "ByteHook initialization failed.");
    }
#else
    OBS_LOG(ANDROID_LOG_WARN, "ByteHook disabled. Network hooks bypassed.");
#endif
}

void teardown() {
#ifndef DISABLE_BYTEHOOK
    bytehook_unhook_all();
    OBS_LOG(ANDROID_LOG_INFO, "Network hooks uninstalled.");
#else
    OBS_LOG(ANDROID_LOG_WARN, "ByteHook disabled. Teardown bypassed.");
#endif
}

} // namespace observer::hooks