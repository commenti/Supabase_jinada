#include "config.h"
#include "ring_buffer.h"
#include <cstdint>
#include <cstring>

#ifndef DISABLE_BYTEHOOK
#include <bytehook.h>

namespace observer::hooks::crypto {
namespace detail {
    // Function pointer typedef for EVP_CipherUpdate to avoid heavy OpenSSL/BoringSSL includes
    using EVP_CipherUpdate_t = int(*)(void* ctx, uint8_t* out, int* out_len, const uint8_t* in, int in_len);
    static EVP_CipherUpdate_t orig_EVP_CipherUpdate = nullptr;

    // Hook: Captures plaintext input and ciphertext output synchronously via lock-free RB
    static int hooked_EVP_CipherUpdate(void* ctx, uint8_t* out, int* out_len, const uint8_t* in, int in_len) {
        // Intercept plaintext before encryption
        if (in != nullptr && in_len > 0) {
            const uint32_t safe_len = (in_len < config::RB_PAYLOAD_MAX) ? static_cast<uint32_t>(in_len) : config::RB_PAYLOAD_MAX;
            core::g_ring_buffer.push(in, safe_len);
        }
        
        const int ret = orig_EVP_CipherUpdate(ctx, out, out_len, in, in_len);
        
        // Intercept ciphertext after encryption/decryption
        if (ret > 0 && out != nullptr && out_len != nullptr && *out_len > 0) {
            const uint32_t safe_len = (*out_len < config::RB_PAYLOAD_MAX) ? static_cast<uint32_t>(*out_len) : config::RB_PAYLOAD_MAX;
            core::g_ring_buffer.push(out, safe_len);
        }
        
        return ret;
    }
} // namespace detail

void install() {
    if (bytehook_init(nullptr, nullptr, nullptr) != BYTEHOOK_SUCCESS) {
        OBS_LOG(ANDROID_LOG_ERROR, "Crypto hooks: ByteHook global init failed.");
        return;
    }
    
    bytehook_hook_single(
        "libcrypto.so",
        nullptr,
        "EVP_CipherUpdate",
        reinterpret_cast<void*>(detail::hooked_EVP_CipherUpdate),
        reinterpret_cast<void**>(&detail::orig_EVP_CipherUpdate),
        nullptr,
        nullptr
    );
    OBS_LOG(ANDROID_LOG_INFO, "Crypto hooks registered successfully.");
}

void uninstall() {
    bytehook_unhook_all();
    OBS_LOG(ANDROID_LOG_INFO, "Crypto hooks uninstalled.");
}
} // namespace observer::hooks::crypto

#else // DISABLE_BYTEHOOK defined

#include <android/log.h>

namespace observer::hooks::crypto {
void install() {
    OBS_LOG(ANDROID_LOG_WARN, "ByteHook disabled. Crypto hooks bypassed (CI mode).");
}
void uninstall() {
    OBS_LOG(ANDROID_LOG_WARN, "ByteHook disabled. Crypto teardown bypassed (CI mode).");
}
} // namespace observer::hooks::crypto

#endif